Pixel Mill Figma bridge

1. Unzip this kit. In the Figma desktop app choose Plugins > Development > Import plugin from manifest and select figma-plugin/manifest.json.
2. Run Pixel Mill Bridge, then choose the included level.figma.json.
3. Edit the Level frame. Assets and appearance variants are reusable native components beside it. Move, resize, rotate, flip, duplicate, reorder or remove pieces. Drag component instances into the Level frame to add pieces. Move the Spawn marker to change the starting point. Select a piece and use the bridge's collision selector for solids, platforms, ladders or decoration.
4. Select the Level frame and choose Export back to Pixel Mill. Open Pixel Mill > Figma import / export > Import changes. Independent local and ChatGPT edits merge; conflicting edits stop with an error. Open as new project keeps both versions separate.

Every import creates a separate Figma snapshot so it cannot overwrite a designer's edits. Coordinates use native pixels and retain the original world origin. Original PNG sources, sprite sheet metadata, artwork bindings and collision data are retained. Modified artwork and new Figma drawings return as separate PNG assets; the original sources remain available. New rectangles become decoration until assigned collision. Keep the Spawn marker and the Level frame's metadata. Resizing painted collision must be uniform; unsupported skew is rejected. Rotation and reflection are supported.

The plugin runs locally without network access, cloud storage, tokens or API keys. It is a development plugin, not a published Community plugin. If your Figma client requests a registered plugin ID, create a new local plugin, keep its assigned manifest ID and copy this kit's code.js and ui.html into that plugin folder.
