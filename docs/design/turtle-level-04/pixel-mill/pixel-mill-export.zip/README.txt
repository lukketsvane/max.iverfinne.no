For editable Figma components and a safe round trip, use Figma import / export in Pixel Mill.
Open level.json in Max Level Studio to continue editing.
level.png is the placed artwork; assets/ contains the transparent pieces.
Garden geometry includes ladders and uses Max x/rise coordinates, origin 0 and baseline 0. It is a geometry reference, not an automatic game deployment.
Max sprite and base movement: lukketsvane/max.iverfinne.no.
